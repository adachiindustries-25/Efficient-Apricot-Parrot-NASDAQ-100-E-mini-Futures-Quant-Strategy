
# EfficientApricotParrot.py
# © 2025 Daniel Chidi. All Rights Reserved.

from AlgorithmImports import *
from datetime import timedelta, time

class EfficientApricotParrot(QCAlgorithm):
    def Initialize(self):
        self.SetStartDate(2022, 1, 1)
        self.SetEndDate(2025, 4, 27)
        self.SetCash(100000)

        future = self.AddFuture(Futures.Indices.NASDAQ_100_E_MINI, Resolution.Minute)
        future.SetFilter(timedelta(0), timedelta(90))
        self.future_symbol = future.Symbol

        self.contract_symbol = None
        self.contract_expiry = None

        self.ema_fast = None
        self.ema_slow = None
        self.atr = None

        self.ema_fast_period = 9
        self.ema_slow_period = 21
        self.atr_period = 14

        self.last_bias = None
        self.bias_confirmation_count = 0
        self.last_trade_time = datetime.min
        self.entry_price = None
        self.stop_loss = None
        self.take_profit = None
        self.risk_per_trade = 650
        self.r_multiple = 1.5
        self.bar_counter = 0
        self.bb_width_threshold = 0.8

        self.max_trades_per_day = 6
        self.daily_trade_count = 0
        self.daily_pnl = 0
        self.max_daily_loss = -2000

        self.last_debug_times = {}
        self.chop_status = False
        self.bos_status = False

        self.Schedule.On(self.DateRules.EveryDay(), self.TimeRules.At(9, 30), self.ResetDailyCounters)

    def OnData(self, data):
        if not self.InTradingWindow(): return

        if self.contract_symbol is None or (self.contract_expiry - self.Time).days <= 5:
            chain = data.FutureChains.get(self.future_symbol)
            if not chain: return
            front = sorted(chain, key=lambda c: c.Expiry)
            if not front: return

            contract = front[0]
            self.contract_symbol = contract.Symbol
            self.contract_expiry = contract.Expiry
            self.AddFutureContract(self.contract_symbol)
            self.ema_fast = self.EMA(self.contract_symbol, self.ema_fast_period, Resolution.Minute)
            self.ema_slow = self.EMA(self.contract_symbol, self.ema_slow_period, Resolution.Minute)
            self.atr = self.ATR(self.contract_symbol, self.atr_period, MovingAverageType.Wilders, Resolution.Minute)
            self.Debug(f"Rolled to {self.contract_symbol} expiring {self.contract_expiry}")
            return

        if not self.IndicatorsReady() or not data.Bars.ContainsKey(self.contract_symbol): return

        price = data.Bars[self.contract_symbol].Close
        bias = self.GetBias()
        if bias == "neutral": return

        self.DebugRateLimit(f"{self.Time} | Bias: {bias} | Price: {price}")

        if self.Portfolio.Invested:
            self.ManageOpenPosition(price, bias)
            return

        if self.Time - self.last_trade_time < timedelta(minutes=60): return
        if self.atr.Current.Value < 10:
            self.DebugRateLimit("ATR too low")
            return

        self.bar_counter += 1

        if self.bar_counter % 5 == 0:
            self.chop_status = self.IsChoppy()
            self.bos_status = self.HasBOS(bias)

        if self.chop_status:
            self.DebugRateLimit("Chop Rescue Mode active")

        if not self.bos_status:
            if self.bar_counter < 90:
                self.DebugRateLimit("BOS not confirmed")
                return
            else:
                self.DebugRateLimit("Fallback: BOS bypassed after 90 bars")

        size = self.GetPositionSize()
        if size == 0:
            self.DebugRateLimit("Position size 0 or margin too low")
            return

        sl_points = self.atr.Current.Value * 1.5
        tp_points = sl_points * self.r_multiple
        self.stop_loss = price - sl_points if bias == "bullish" else price + sl_points
        self.take_profit = price + tp_points if bias == "bullish" else price - tp_points
        quantity = size if bias == "bullish" else -size

        self.MarketOrder(self.contract_symbol, quantity)
        self.entry_price = price
        self.last_trade_time = self.Time
        self.last_bias = bias
        self.bar_counter = 0
        self.Debug(f"ENTRY @ {self.Time} | Qty: {quantity} | SL: {self.stop_loss} | TP: {self.take_profit}")

    def IndicatorsReady(self):
        return all([self.ema_fast and self.ema_fast.IsReady,
                    self.ema_slow and self.ema_slow.IsReady,
                    self.atr and self.atr.IsReady])

    def GetBias(self):
        if self.ema_fast.Current.Value > self.ema_slow.Current.Value:
            return "bullish"
        elif self.ema_fast.Current.Value < self.ema_slow.Current.Value:
            return "bearish"
        return "neutral"

    def HasBOS(self, bias):
        bars = self.History(self.contract_symbol, 20, Resolution.Minute)
        if bars.empty: return False
        highs = bars['high']
        lows = bars['low']
        if bias == "bullish":
            return highs.iloc[-1] >= 0.95 * max(highs[:-1])
        else:
            return lows.iloc[-1] <= 1.05 * min(lows[:-1])

    def IsChoppy(self):
        bars = self.History(self.contract_symbol, 20, Resolution.Minute)
        if bars.empty: return False
        width = (bars['high'].max() - bars['low'].min()) / bars['low'].min() * 100
        return width < self.bb_width_threshold

    def GetPositionSize(self):
        tick_value = 20
        sl_points = self.atr.Current.Value * 1.5
        cost = sl_points * tick_value
        if cost == 0:
            return 1
        size = int(self.risk_per_trade / cost)
        contract_security = self.Securities[self.contract_symbol]
        if self.Portfolio.MarginRemaining < 5000:
            return 0
        margin_params = MaintenanceMarginParameters(contract_security, size, 0, 0)
        maintenance_margin = contract_security.MarginModel.GetMaintenanceMargin(margin_params).Value
        required_margin = maintenance_margin * size
        if self.Portfolio.MarginRemaining < required_margin:
            return 0
        return max(1, size)

    def ManageOpenPosition(self, price, bias):
        gain = abs(price - self.entry_price)
        risk = self.atr.Current.Value * 1.5
        if gain >= 1.5 * risk:
            self.Debug("Trailing stop triggered")
            bars = self.History(self.contract_symbol, 2, Resolution.Minute)
            if bars.empty: return
            trail_sl = min([bar.low for bar in bars.itertuples()]) if bias == "bullish" else max([bar.high for bar in bars.itertuples()])
            if (bias == "bullish" and price < trail_sl) or (bias == "bearish" and price > trail_sl):
                self.Liquidate(self.contract_symbol)
                self.Debug(f"Exit: Trailed | PnL: {self.Portfolio[self.contract_symbol].UnrealizedProfit}")
        elif self.Time - self.last_trade_time > timedelta(minutes=60):
            self.Liquidate(self.contract_symbol)
            self.Debug(f"Exit: Timed | PnL: {self.Portfolio[self.contract_symbol].UnrealizedProfit}")

    def DebugRateLimit(self, message, interval_minutes=30):
        last_logged = self.last_debug_times.get(message, datetime.min)
        if self.Time - last_logged > timedelta(minutes=interval_minutes):
            self.Debug(message)
            self.last_debug_times[message] = self.Time

    def InTradingWindow(self):
        time_now = self.Time.time()
        return (time(9, 45) <= time_now <= time(11, 30)) or (time(13, 15) <= time_now <= time(15, 45))

    def ResetDailyCounters(self):
        self.daily_trade_count = 0
        self.daily_pnl = 0
