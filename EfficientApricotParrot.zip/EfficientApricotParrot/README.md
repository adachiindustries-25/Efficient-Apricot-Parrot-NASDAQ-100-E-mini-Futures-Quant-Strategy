
# Efficient Apricot Parrot Strategy
Author: Daniel Chidi

## Overview
This is a QuantConnect Futures trading algorithm focused on NASDAQ-100 E-mini futures. It combines BOS (Break of Structure), Fair Value Gap (FVG), ATR-based adaptive position sizing, and chop detection logic.

## Features
- BOS + FVG detection with fallback entry logic
- HTF EMA(9/21) bias filtering
- Adaptive ATR-based position sizing
- Chop Rescue Mode for low volatility zones
- Daily trade cap and PnL protection
- Trailing stop after 1.5R gains
- Efficient runtime optimizations

## Backtest Period
- From: 2022-01-01
- To: 2025-04-27

## How to Use
1. Clone the repo.
2. Copy `EfficientApricotParrot.py` into a QuantConnect Python project.
3. Run backtest.

## License
© 2025 Daniel Chidi. All Rights Reserved.
